"""자동화, 녹화, 녹화 재생을 제공하는 GUI."""

from __future__ import annotations

import json
import threading
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, ttk

import customtkinter as ctk

from automation.app_logger import create_logger
from automation.recorder import BrowserRecorder
from automation.recordings import RecordingStore
from automation.replay import RecordingReplayer
from automation.workflow import AutomationWorkflow, WorkflowInput


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SETTINGS_PATH = PROJECT_ROOT / "config" / "settings.json"
RECORDINGS_PATH = PROJECT_ROOT / "recordings"
LOGS_PATH = PROJECT_ROOT / "logs"


class MainWindow:
    """GUI 스레드를 차단하지 않도록 모든 브라우저 작업을 별도 스레드에서 실행한다."""

    def __init__(self) -> None:
        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("blue")

        self.root = ctk.CTk()
        self.root.title("PPW 웹 업무 자동화")
        self.root.geometry("820x760")
        self.root.minsize(700, 620)

        self.automation_stop_event = threading.Event()
        self.record_stop_event = threading.Event()
        self.replay_stop_event = threading.Event()
        self.automation_worker: threading.Thread | None = None
        self.record_worker: threading.Thread | None = None
        self.replay_worker: threading.Thread | None = None
        self.recording_store = RecordingStore(RECORDINGS_PATH)
        self.file_logger = create_logger(LOGS_PATH)
        self.recording_paths: list[Path] = []
        self.pending_recording: dict | None = None
        self.save_requested = False

        self.url_var = tk.StringVar(value=self._load_site_url())
        self.record_url_var = tk.StringVar(value=self._load_site_url())
        self.username_var = tk.StringVar()
        self.password_var = tk.StringVar()
        self.otp_var = tk.StringVar()
        self.date_var = tk.StringVar()
        self.record_name_var = tk.StringVar()

        self._build_ui()
        self._refresh_recordings()
        self._post_log("프로그램이 시작되었습니다.")

    def _load_site_url(self) -> str:
        try:
            with SETTINGS_PATH.open("r", encoding="utf-8") as file:
                return json.load(file).get("site_url", "")
        except (OSError, json.JSONDecodeError):
            return ""

    def _build_ui(self) -> None:
        frame = ctk.CTkFrame(self.root)
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        ctk.CTkLabel(
            frame,
            text="웹 업무 자동화",
            font=ctk.CTkFont(size=22, weight="bold"),
        ).pack(anchor="w", padx=20, pady=(18, 10))

        form = ctk.CTkFrame(frame, fg_color="transparent")
        form.pack(fill="x", padx=20)
        form.grid_columnconfigure(1, weight=1)
        self._add_field(form, 0, "사이트 URL", self.url_var)
        self._add_field(form, 1, "아이디", self.username_var)
        self._add_field(form, 2, "비밀번호", self.password_var, show="*")
        self._add_field(form, 3, "2차 인증 OTP", self.otp_var, show="*", placeholder="6자리 OTP")
        self._add_field(form, 4, "업무 날짜", self.date_var, placeholder="YYYY-MM-DD")

        button_frame = ctk.CTkFrame(frame, fg_color="transparent")
        button_frame.pack(fill="x", padx=20, pady=(10, 8))
        self.start_button = ctk.CTkButton(
            button_frame, text="설정 기반 자동화", command=self.start_automation
        )
        self.start_button.pack(side="left", padx=(0, 8))
        self.stop_button = ctk.CTkButton(
            button_frame,
            text="현재 작업 중지",
            command=self.stop_current_task,
            state="disabled",
            fg_color="#9b2c2c",
            hover_color="#7b2020",
        )
        self.stop_button.pack(side="left")

        self._build_recording_panel(frame)

        ctk.CTkLabel(frame, text="실행 로그").pack(anchor="w", padx=20, pady=(8, 0))
        self.log_box = ctk.CTkTextbox(frame, height=170, state="disabled")
        self.log_box.pack(fill="both", expand=True, padx=20, pady=(6, 18))

    def _build_recording_panel(self, parent: ctk.CTkFrame) -> None:
        panel = ctk.CTkFrame(parent)
        panel.pack(fill="x", padx=20, pady=8)
        panel.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            panel, text="동작 녹화 및 재실행", font=ctk.CTkFont(weight="bold")
        ).grid(row=0, column=0, columnspan=4, padx=12, pady=(10, 5), sticky="w")

        record_url_entry = ctk.CTkEntry(
            panel,
            textvariable=self.record_url_var,
            placeholder_text="녹화할 사이트 URL",
        )
        record_url_entry.grid(row=1, column=0, columnspan=4, padx=12, pady=5, sticky="ew")

        name_entry = ctk.CTkEntry(
            panel,
            textvariable=self.record_name_var,
            placeholder_text="녹화 이름 (예: 업무등록)",
        )
        name_entry.grid(row=2, column=0, padx=(12, 6), pady=5, sticky="ew")
        self.record_button = ctk.CTkButton(
            panel, text="녹화 시작", width=110, command=self.start_recording
        )
        self.record_button.grid(row=2, column=1, padx=6, pady=5)
        self.save_record_button = ctk.CTkButton(
            panel,
            text="녹화 저장",
            width=110,
            command=self.save_recording,
            state="disabled",
            fg_color="#2f855a",
            hover_color="#276749",
        )
        self.save_record_button.grid(row=2, column=2, padx=6, pady=5)
        self.replay_button = ctk.CTkButton(
            panel, text="선택 재실행", width=110, command=self.replay_selected
        )
        self.replay_button.grid(row=2, column=3, padx=(6, 12), pady=5)

        panel.grid_columnconfigure(1, weight=1)
        panel.grid_columnconfigure(3, weight=1)
        self.recording_list = ttk.Treeview(
            panel,
            columns=("name", "url"),
            show="headings",
            height=5,
            selectmode="browse",
        )
        self.recording_list.heading("name", text="녹화 이름")
        self.recording_list.heading("url", text="사이트 URL")
        self.recording_list.column("name", width=170, minwidth=120, anchor="w")
        self.recording_list.column("url", width=420, minwidth=220, anchor="w")
        self.recording_list.grid(row=3, column=0, columnspan=3, padx=(12, 6), pady=(5, 10), sticky="ew")
        self.delete_button = ctk.CTkButton(
            panel,
            text="선택 삭제",
            width=110,
            fg_color="#666666",
            hover_color="#4d4d4d",
            command=self.delete_selected_recording,
        )
        self.delete_button.grid(row=3, column=3, padx=(6, 12), pady=5, sticky="n")

    @staticmethod
    def _add_field(
        parent: ctk.CTkFrame,
        row: int,
        label: str,
        variable: tk.StringVar,
        show: str | None = None,
        placeholder: str | None = None,
    ) -> None:
        ctk.CTkLabel(parent, text=label, width=90, anchor="w").grid(
            row=row, column=0, padx=(0, 10), pady=4, sticky="w"
        )
        entry = ctk.CTkEntry(parent, textvariable=variable, show=show)
        if placeholder:
            entry.configure(placeholder_text=placeholder)
        entry.grid(row=row, column=1, pady=4, sticky="ew")

    def _append_log(self, message: str) -> None:
        self.log_box.configure(state="normal")
        self.log_box.insert("end", message + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def _post_log(self, message: str) -> None:
        self.file_logger.info(message)
        self.root.after(0, self._append_log, message)

    def _is_busy(self) -> bool:
        return any(
            worker and worker.is_alive()
            for worker in (self.automation_worker, self.record_worker, self.replay_worker)
        )

    def _update_controls(self) -> None:
        busy = self._is_busy()
        state = "disabled" if busy else "normal"
        self.start_button.configure(state=state)
        self.record_button.configure(state=state)
        self.replay_button.configure(state=state)
        self.delete_button.configure(state=state)
        save_available = bool(
            (self.record_worker and self.record_worker.is_alive())
            or (self.pending_recording and not busy)
        )
        self.save_record_button.configure(state="normal" if save_available else "disabled")
        self.stop_button.configure(state="normal" if busy else "disabled")

    def start_automation(self) -> None:
        if self._is_busy():
            return
        values = [
            self.url_var.get().strip(),
            self.username_var.get().strip(),
            self.password_var.get(),
            self.date_var.get().strip(),
        ]
        if not all(values):
            messagebox.showwarning("입력 확인", "사이트 URL, 아이디, 비밀번호, 날짜를 입력하세요.")
            return

        self.automation_stop_event.clear()
        workflow_input = WorkflowInput(
            site_url=values[0],
            username=values[1],
            password=values[2],
            otp=self.otp_var.get().strip(),
            work_date=values[3],
        )
        self._append_log("설정 기반 자동화를 시작합니다.")
        self.automation_worker = threading.Thread(
            target=self._run_automation, args=(workflow_input,), daemon=True
        )
        self.automation_worker.start()
        self._update_controls()

    def _run_automation(self, workflow_input: WorkflowInput) -> None:
        try:
            AutomationWorkflow(
                settings_path=SETTINGS_PATH,
                stop_event=self.automation_stop_event,
                log=self._post_log,
            ).run(workflow_input)
        except Exception as exc:  # noqa: BLE001 - GUI에 자동화 오류를 표시한다.
            self._post_log(f"오류: {exc}")
        finally:
            self.root.after(0, self._automation_finished)

    def _automation_finished(self) -> None:
        self.automation_worker = None
        self._append_log("설정 기반 자동화가 종료되었습니다.")
        self._update_controls()

    def start_recording(self) -> None:
        if self._is_busy():
            return
        if self.pending_recording:
            should_discard = messagebox.askyesno(
                "미저장 녹화",
                "이전에 녹화했지만 저장하지 않은 동작이 있습니다. 새 녹화를 시작할까요?",
            )
            if not should_discard:
                return
            self.pending_recording = None

        url = self.record_url_var.get().strip()
        if not url:
            messagebox.showwarning("입력 확인", "녹화 영역의 사이트 URL을 입력하세요.")
            return

        name = self.record_name_var.get().strip()
        if not name:
            name = f"recording_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            self.record_name_var.set(name)

        self.record_stop_event.clear()
        self.save_requested = False
        self._append_log("녹화를 시작합니다. 새 브라우저에서 동작을 수행하세요.")
        self._post_log(f"녹화 대상 URL: {url}")
        self.record_worker = threading.Thread(
            target=self._run_recording, args=(url, name), daemon=True
        )
        self.record_worker.start()
        self._update_controls()

    def _run_recording(self, url: str, name: str) -> None:
        try:
            settings = self._load_settings()
            actions = BrowserRecorder(settings).record(url, self.record_stop_event, self._post_log)
            self.root.after(0, self._recording_ready, name, url, actions)
        except Exception as exc:  # noqa: BLE001 - GUI에 녹화 오류를 표시한다.
            self._post_log(f"녹화 오류: {exc}")
        finally:
            self.root.after(0, self._recording_finished)

    def _recording_ready(self, name: str, url: str, actions: list[dict]) -> None:
        self.pending_recording = {"name": name, "url": url, "actions": actions}
        self._append_log("녹화가 종료되었습니다. '녹화 저장' 버튼을 눌러 저장하세요.")
        if self.save_requested:
            self._save_pending_recording()
        else:
            self._update_controls()

    def save_recording(self) -> None:
        if self.record_worker and self.record_worker.is_alive():
            self.save_requested = True
            self.record_stop_event.set()
            self._append_log("녹화를 종료한 뒤 자동으로 저장합니다.")
            return
        self._save_pending_recording()

    def _save_pending_recording(self) -> None:
        if not self.pending_recording:
            messagebox.showwarning("저장할 녹화 없음", "먼저 녹화를 종료하세요.")
            return

        name = self.record_name_var.get().strip() or self.pending_recording["name"]
        try:
            path = self.recording_store.save(
                name,
                self.pending_recording["url"],
                self.pending_recording["actions"],
            )
        except OSError as exc:
            messagebox.showerror("녹화 저장 오류", str(exc))
            return

        self.pending_recording = None
        self.save_requested = False
        self._refresh_recordings()
        self._append_log(f"녹화를 저장했습니다: {path.name}")
        self._update_controls()

    def _recording_finished(self) -> None:
        self.record_worker = None
        self._append_log("녹화 작업이 종료되었습니다.")
        self._update_controls()

    def replay_selected(self) -> None:
        if self._is_busy():
            return
        selection = self.recording_list.selection()
        if not selection:
            messagebox.showwarning("선택 확인", "재실행할 녹화를 선택하세요.")
            return

        path = self.recording_paths[int(selection[0])]
        try:
            recording = self.recording_store.load(path)
        except RuntimeError as exc:
            messagebox.showerror("녹화 읽기 오류", str(exc))
            return

        username = self.username_var.get()
        password = self.password_var.get()
        otp = self.otp_var.get().strip()
        if not username or not password:
            messagebox.showwarning(
                "로그인 정보 필요",
                "아이디와 비밀번호를 GUI에 입력하세요.",
            )
            return
        serialized_actions = json.dumps(recording["actions"], ensure_ascii=False)
        if "{{otp}}" in serialized_actions and not otp:
            messagebox.showwarning("OTP 필요", "이 녹화에는 OTP 입력이 포함되어 있습니다.")
            return
        variables = {
            "username": username,
            "password": password,
            "otp": otp,
            "work_date": self.date_var.get(),
        }
        self.replay_stop_event.clear()
        self._append_log(f"녹화를 재실행합니다: {self.recording_store.title(path)}")
        self.replay_worker = threading.Thread(
            target=self._run_replay, args=(path, variables), daemon=True
        )
        self.replay_worker.start()
        self._update_controls()

    def _run_replay(self, path: Path, variables: dict[str, str]) -> None:
        try:
            settings = self._load_settings()
            recording = self.recording_store.load(path)
            RecordingReplayer(settings, PROJECT_ROOT / "artifacts").run(
                recording["actions"], variables, self.replay_stop_event, self._post_log
            )
            self._post_log("녹화 재실행이 완료되었습니다.")
        except Exception as exc:  # noqa: BLE001 - GUI에 재실행 오류를 표시한다.
            self._post_log(f"재실행 오류: {exc}")
        finally:
            self.root.after(0, self._replay_finished)

    def _replay_finished(self) -> None:
        self.replay_worker = None
        self._append_log("재실행 작업이 종료되었습니다.")
        self._update_controls()

    def delete_selected_recording(self) -> None:
        if self._is_busy():
            return
        selection = self.recording_list.selection()
        if not selection:
            messagebox.showwarning("선택 확인", "삭제할 녹화를 선택하세요.")
            return
        path = self.recording_paths[int(selection[0])]
        if not messagebox.askyesno("삭제 확인", f"'{self.recording_store.title(path)}' 녹화를 삭제할까요?"):
            return
        try:
            self.recording_store.delete(path)
            self._refresh_recordings()
            self._append_log(f"녹화를 삭제했습니다: {path.name}")
        except (OSError, ValueError) as exc:
            messagebox.showerror("삭제 오류", str(exc))

    def _refresh_recordings(self) -> None:
        self.recording_paths = self.recording_store.list_paths()
        existing_items = self.recording_list.get_children()
        if existing_items:
            self.recording_list.delete(*existing_items)
        for index, path in enumerate(self.recording_paths):
            try:
                recording = self.recording_store.load(path)
                url = recording.get("start_url", "")
            except RuntimeError:
                url = "(녹화 파일을 읽을 수 없음)"
            self.recording_list.insert(
                "", "end", iid=str(index), values=(self.recording_store.title(path), url)
            )

    def stop_current_task(self) -> None:
        if self.automation_worker and self.automation_worker.is_alive():
            self.automation_stop_event.set()
        if self.record_worker and self.record_worker.is_alive():
            self.record_stop_event.set()
        if self.replay_worker and self.replay_worker.is_alive():
            self.replay_stop_event.set()
        if self._is_busy():
            self._append_log("중지 요청을 보냈습니다. 현재 브라우저 단계 종료 후 중지됩니다.")

    def _load_settings(self) -> dict:
        try:
            with SETTINGS_PATH.open("r", encoding="utf-8") as file:
                return json.load(file)
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError("config/settings.json을 읽을 수 없습니다.") from exc

    def run(self) -> None:
        self.root.mainloop()
