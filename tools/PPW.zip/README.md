# PPW 웹 업무 자동화 샘플

CustomTkinter GUI에서 로그인 정보와 업무 날짜를 입력하면 Playwright가 다음 순서를 실행하는 기본 골격입니다.

1. 사이트 접속
2. 로그인
3. `업무 등록` 메뉴 클릭
4. `등록 대상` 텍스트 클릭
5. 날짜 입력
6. 저장 버튼 클릭
7. `저장되었습니다` 메시지 확인

## 동작 녹화 및 재실행

프로그램의 `녹화 시작` 버튼을 누르면 별도의 Chromium 창이 열립니다. 해당 창에서 로그인, 메뉴 클릭, 입력, 저장 등 원하는 동작을 수행한 뒤 `현재 작업 중지` 또는 `녹화 저장` 버튼을 누릅니다. 녹화가 종료되면 `녹화 저장` 버튼으로 `recordings/` 폴더에 JSON으로 저장할 수 있습니다.

저장된 녹화를 목록에서 선택해 `선택 재실행`할 수 있으며, 선택 후 `선택 삭제`로 삭제할 수 있습니다. 녹화 중 아이디·비밀번호·OTP 입력은 실제 값 대신 `{{username}}`, `{{password}}`, `{{otp}}` placeholder로 저장되고, 재실행 시 GUI 입력값을 사용합니다.

## 로그

실행 로그는 `logs/ppw.log`에 기록됩니다. 로그인 URL, 로그인 시도·성공·실패, 녹화 URL, 재실행 URL과 오류를 남기며 비밀번호는 기록하지 않습니다. 프로그램이 관찰하지 못한 과거 브라우저 세션의 로그인 결과는 사후 복구할 수 없습니다.

녹화 방식은 DOM selector를 기록하므로 일반적인 버튼·입력·select·checkbox에 적합합니다. 캔버스, OS 파일 선택 창, CAPTCHA·MFA는 자동 녹화 대상이 아니며 사용자 개입이 필요합니다.

## 설치

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m playwright install chromium
```

## 실행

```powershell
python main.py
```

## 실제 사이트 적용

`config/settings.json`의 `site_url`과 `selectors`를 실제 사이트의 DOM에 맞게 수정해야 합니다. 현재 값은 구조 확인용 예시입니다.

가능하면 좌표나 XPath보다 다음 locator를 우선 사용하세요.

- 고유한 `id`, `name`, `data-*` 속성
- `get_by_role`, `get_by_label`에 해당하는 접근성 정보
- 고유 CSS selector

로그인 정보와 OTP는 녹화 JSON과 로그에 저장하지 않습니다. 매 실행 시 GUI의 아이디·비밀번호·OTP 입력값을 녹화 placeholder에 매핑합니다. CAPTCHA나 MFA가 나타나는 경우 자동 우회하지 말고 사용자 확인 단계를 두어야 합니다.

설정 기반 자동화에서 OTP를 사용하려면 `config/settings.json`의 `selectors.login`에 `otp` selector를 추가할 수 있습니다. OTP 입력 후 별도 제출 버튼이 있으면 `otp_submit` selector도 추가합니다.

## 구조

```text
main.py
├─ gui/main_window.py       # GUI와 작업 스레드
├─ automation/browser.py    # 브라우저 수명 관리
├─ automation/workflow.py   # 전체 업무 순서
└─ automation/pages/        # 페이지별 동작(Page Object)
   ├─ login_page.py
   └─ target_page.py
```
