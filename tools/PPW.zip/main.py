"""PPW 웹 업무 자동화 프로그램의 시작점."""

from gui.main_window import MainWindow


if __name__ == "__main__":
    MainWindow().run()
