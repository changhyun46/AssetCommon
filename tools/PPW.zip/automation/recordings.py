"""녹화 파일의 저장·조회·삭제를 담당한다."""

from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path


class RecordingStore:
    def __init__(self, directory: Path) -> None:
        self.directory = directory
        self.directory.mkdir(parents=True, exist_ok=True)

    def list_paths(self) -> list[Path]:
        return sorted(self.directory.glob("*.json"), key=lambda path: path.stat().st_mtime, reverse=True)

    def title(self, path: Path) -> str:
        try:
            with path.open("r", encoding="utf-8") as file:
                return str(json.load(file).get("name", path.stem))
        except (OSError, json.JSONDecodeError):
            return path.stem

    def save(self, name: str, start_url: str, actions: list[dict]) -> Path:
        safe_name = re.sub(r"[^0-9A-Za-z가-힣._-]+", "_", name).strip("._")
        if not safe_name:
            safe_name = "recording"

        path = self.directory / f"{safe_name}.json"
        if path.exists():
            suffix = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = self.directory / f"{safe_name}_{suffix}.json"

        payload = {
            "name": name or safe_name,
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "start_url": start_url,
            "actions": actions,
        }
        with path.open("w", encoding="utf-8") as file:
            json.dump(payload, file, ensure_ascii=False, indent=2)
        return path

    def load(self, path: Path) -> dict:
        resolved = self._inside_directory(path)
        try:
            with resolved.open("r", encoding="utf-8") as file:
                data = json.load(file)
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"녹화 파일을 읽을 수 없습니다: {resolved.name}") from exc

        if not isinstance(data.get("actions"), list):
            raise RuntimeError(f"녹화 파일 형식이 올바르지 않습니다: {resolved.name}")
        return data

    def delete(self, path: Path) -> None:
        self._inside_directory(path).unlink(missing_ok=False)

    def _inside_directory(self, path: Path) -> Path:
        resolved = path.resolve()
        directory = self.directory.resolve()
        if resolved.parent != directory or resolved.suffix.lower() != ".json":
            raise ValueError("허용되지 않은 녹화 파일 경로입니다.")
        return resolved
