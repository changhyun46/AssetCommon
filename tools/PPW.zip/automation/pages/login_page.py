"""로그인 페이지 동작."""

from __future__ import annotations

from playwright.sync_api import Page


class LoginPage:
    def __init__(self, page: Page, selectors: dict, timeout_ms: int) -> None:
        self.page = page
        self.selectors = selectors
        self.timeout_ms = timeout_ms

    def login(self, username: str, password: str, otp: str = "") -> None:
        self.page.locator(self.selectors["username"]).fill(username)
        self.page.locator(self.selectors["password"]).fill(password)
        self.page.locator(self.selectors["submit"]).click()
        self.page.wait_for_load_state("domcontentloaded", timeout=self.timeout_ms)

        otp_selector = self.selectors.get("otp")
        if otp_selector and otp:
            self.page.locator(otp_selector).fill(otp)
            otp_submit = self.selectors.get("otp_submit")
            if otp_submit:
                self.page.locator(otp_submit).click()
                self.page.wait_for_load_state("domcontentloaded", timeout=self.timeout_ms)
