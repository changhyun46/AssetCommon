"""로그인 후 실제 업무를 수행하는 Page Object."""

from __future__ import annotations

from playwright.sync_api import Page


class TargetPage:
    def __init__(self, page: Page, selectors: dict, timeout_ms: int) -> None:
        self.page = page
        self.selectors = selectors
        self.timeout_ms = timeout_ms

    def execute(self, work_date: str, should_stop) -> None:
        """샘플 업무 순서: 메뉴 클릭 -> 텍스트 검색/클릭 -> 날짜 입력 -> 저장."""
        self._check_stop(should_stop)
        self.page.locator(self.selectors["menu"]).click()

        self._check_stop(should_stop)
        self.page.get_by_text(
            self.selectors["search_text"], exact=True
        ).click(timeout=self.timeout_ms)

        self._check_stop(should_stop)
        self.page.locator(self.selectors["date"]).fill(work_date)
        self.page.locator(self.selectors["save"]).click()

        self.page.get_by_text(
            self.selectors["success_text"], exact=True
        ).wait_for(timeout=self.timeout_ms)

    @staticmethod
    def _check_stop(should_stop) -> None:
        if should_stop():
            raise RuntimeError("사용자가 자동화를 중지했습니다.")
