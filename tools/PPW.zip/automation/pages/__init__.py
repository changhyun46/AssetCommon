"""사이트별 Page Object 모음."""
