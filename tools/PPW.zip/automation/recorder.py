"""사용자 브라우저 조작을 Playwright action 목록으로 기록한다."""

from __future__ import annotations

from threading import Event
from typing import Callable

from playwright.sync_api import Browser, Page, Playwright, sync_playwright


RECORDER_SCRIPT = r"""
(() => {
  if (window.__ppwRecorderInstalled) return;
  window.__ppwRecorderInstalled = true;
  let sequence = 0;
  const inputTimers = new WeakMap();

  const quote = (value) => String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  const unique = (selector) => {
    try { return document.querySelectorAll(selector).length === 1; }
    catch (_) { return false; }
  };
  const selectorFor = (element) => {
    if (!(element instanceof Element)) return null;
    if (element.id) {
      const selector = `#${CSS.escape(element.id)}`;
      if (unique(selector)) return selector;
    }
    for (const attribute of ["data-testid", "name", "aria-label"]) {
      const value = element.getAttribute(attribute);
      if (value) {
        const selector = `${element.tagName.toLowerCase()}[${attribute}="${quote(value)}"]`;
        if (unique(selector)) return selector;
      }
    }
    const parts = [];
    let current = element;
    while (current && current.nodeType === 1 && parts.length < 6) {
      let part = current.tagName.toLowerCase();
      if (current.classList.length) {
        part += "." + Array.from(current.classList).slice(0, 2).map(CSS.escape).join(".");
      }
      let index = 1;
      let sibling = current;
      while ((sibling = sibling.previousElementSibling)) {
        if (sibling.tagName === current.tagName) index++;
      }
      part += `:nth-of-type(${index})`;
      parts.unshift(part);
      const candidate = parts.join(" > ");
      if (unique(candidate)) return candidate;
      current = current.parentElement;
    }
    return parts.join(" > ") || null;
  };
  const placeholderFor = (element) => {
    const identity = `${element.name || ""} ${element.id || ""} ${element.getAttribute("aria-label") || ""} ${element.getAttribute("autocomplete") || ""}`.toLowerCase();
    if (element.type === "password" || /password|passwd|비밀번호/.test(identity)) return "{{password}}";
    if (/otp|one[-_ ]?time|verification|auth[-_ ]?code|인증번호|2차 인증/.test(identity)) return "{{otp}}";
    if (/username|user[_-]?id|login|email|아이디|(^|[\s_-])(id|login|email)([\s_-]|$)/.test(identity)) return "{{username}}";
    return element.value ?? "";
  };
  const emit = (action) => {
    if (typeof window.ppw_record !== "function") return;
    window.ppw_record({ ...action, sequence: sequence++ });
  };
  const elementFromEvent = (event) => {
    const target = event.target;
    return target instanceof Element
      ? target.closest("input, textarea, select, button, a, [role='button']") || target
      : null;
  };

  document.addEventListener("click", (event) => {
    const element = elementFromEvent(event);
    const selector = element && selectorFor(element);
    if (selector) emit({ type: "click", selector });
  }, true);

  document.addEventListener("input", (event) => {
    const element = event.target;
    if (!(element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement)) return;
    if (element instanceof HTMLInputElement && ["checkbox", "radio"].includes(element.type)) return;
    const selector = selectorFor(element);
    if (!selector) return;
    clearTimeout(inputTimers.get(element));
    inputTimers.set(element, setTimeout(() => {
      emit({ type: "fill", selector, value: placeholderFor(element) });
    }, 350));
  }, true);

  document.addEventListener("change", (event) => {
    const element = event.target;
    const selector = element instanceof Element ? selectorFor(element) : null;
    if (!selector) return;
    if (element instanceof HTMLInputElement && element.type === "checkbox") {
      emit({ type: element.checked ? "check" : "uncheck", selector });
    } else if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
      clearTimeout(inputTimers.get(element));
      emit({ type: "fill", selector, value: placeholderFor(element) });
    } else if (element instanceof HTMLSelectElement) {
      emit({ type: "select", selector, value: element.value });
    }
  }, true);
})();
"""


class BrowserRecorder:
    def __init__(self, settings: dict) -> None:
        self.settings = settings

    def record(
        self,
        start_url: str,
        stop_event: Event,
        log: Callable[[str], None],
    ) -> list[dict]:
        browser_options = self.settings.get("browser", {})
        actions: list[dict] = [{"type": "goto", "url": start_url}]
        last_url = start_url
        ready = False

        with sync_playwright() as playwright:
            browser = self._launch(playwright, browser_options)
            context = browser.new_context(viewport={"width": 1440, "height": 900})
            page = context.new_page()

            def append_action(_source, action) -> None:
                if isinstance(action, dict) and action.get("type"):
                    actions.append(dict(action))

            def on_navigate(frame) -> None:
                nonlocal last_url
                if ready and frame == page.main_frame and frame.url and frame.url != last_url:
                    actions.append({"type": "goto", "url": frame.url})
                    last_url = frame.url

            page.expose_binding("ppw_record", append_action)
            page.add_init_script(RECORDER_SCRIPT)
            page.on("framenavigated", on_navigate)
            try:
                log("브라우저에서 원하는 동작을 수행하세요.")
                page.goto(start_url, wait_until="domcontentloaded")
                ready = True
                while not stop_event.is_set():
                    page.wait_for_timeout(100)
                page.wait_for_timeout(500)  # 마지막 입력 이벤트 debounce 대기
            finally:
                context.close()
                browser.close()

        return self._without_sequence(actions)

    @staticmethod
    def _without_sequence(actions: list[dict]) -> list[dict]:
        return [{key: value for key, value in action.items() if key != "sequence"} for action in actions]

    @staticmethod
    def _launch(playwright: Playwright, options: dict) -> Browser:
        browser_type = getattr(playwright, options.get("browser", "chromium"))
        return browser_type.launch(
            headless=False,
            slow_mo=int(options.get("slow_mo_ms", 0)),
        )
