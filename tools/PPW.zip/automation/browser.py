"""Playwright 브라우저 생명주기 관리."""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Iterator

from playwright.sync_api import Browser, BrowserContext, Page, Playwright, sync_playwright


class BrowserSession:
    """자동화 한 번의 실행에 필요한 브라우저와 페이지를 관리한다."""

    def __init__(self, settings: dict, artifacts_dir: Path) -> None:
        self.settings = settings
        self.artifacts_dir = artifacts_dir
        self.last_failure_screenshot: Path | None = None

    @contextmanager
    def open(self) -> Iterator[Page]:
        browser_options = self.settings.get("browser", {})
        self.artifacts_dir.mkdir(parents=True, exist_ok=True)

        with sync_playwright() as playwright:
            browser: Browser = self._launch(playwright, browser_options)
            context: BrowserContext = browser.new_context(
                viewport={"width": 1440, "height": 900},
                accept_downloads=True,
            )
            page = context.new_page()
            try:
                yield page
            except Exception:
                self.last_failure_screenshot = self._save_failure_screenshot(page)
                raise
            finally:
                context.close()
                browser.close()

    def _save_failure_screenshot(self, page: Page) -> Path | None:
        path = self.artifacts_dir / (
            f"failure_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.png"
        )
        try:
            page.screenshot(path=str(path), full_page=True)
        except Exception:
            return None
        return path

    @staticmethod
    def _launch(playwright: Playwright, options: dict) -> Browser:
        browser_name = options.get("browser", "chromium")
        browser_type = getattr(playwright, browser_name)
        return browser_type.launch(
            headless=bool(options.get("headless", False)),
            slow_mo=int(options.get("slow_mo_ms", 0)),
        )
