"""저장된 action 목록을 Playwright로 재실행한다."""

from __future__ import annotations

from pathlib import Path
from threading import Event
from typing import Callable

from playwright.sync_api import Browser, Page, Playwright, sync_playwright


class RecordingReplayer:
    def __init__(self, settings: dict, artifacts_dir: Path) -> None:
        self.settings = settings
        self.artifacts_dir = artifacts_dir

    def run(
        self,
        actions: list[dict],
        variables: dict[str, str],
        stop_event: Event,
        log: Callable[[str], None],
    ) -> None:
        browser_options = self.settings.get("browser", {})
        timeout_ms = int(self.settings.get("timeouts", {}).get("element_ms", 10000))
        self.artifacts_dir.mkdir(parents=True, exist_ok=True)

        with sync_playwright() as playwright:
            browser = self._launch(playwright, browser_options)
            context = browser.new_context(viewport={"width": 1440, "height": 900})
            page = context.new_page()
            page.set_default_timeout(timeout_ms)
            try:
                for index, action in enumerate(actions, start=1):
                    self._check_stop(stop_event)
                    action_type = action.get("type")
                    log(f"동작 {index}/{len(actions)}: {action_type}")
                    if action_type == "goto":
                        log(f"접속 URL: {action.get('url', '')}")
                    self._execute(page, action, variables, timeout_ms)
            except Exception:
                screenshot = self.artifacts_dir / "replay_failure.png"
                try:
                    page.screenshot(path=str(screenshot), full_page=True)
                    log(f"실패 화면을 저장했습니다: {screenshot}")
                except Exception:
                    pass
                raise
            finally:
                context.close()
                browser.close()

    @classmethod
    def _execute(cls, page: Page, action: dict, variables: dict[str, str], timeout_ms: int) -> None:
        action_type = action.get("type")
        if action_type == "goto":
            page.goto(cls._replace(action["url"], variables), wait_until="domcontentloaded")
        elif action_type == "click":
            page.locator(action["selector"]).click(timeout=timeout_ms)
        elif action_type == "fill":
            page.locator(action["selector"]).fill(cls._replace(action.get("value", ""), variables))
        elif action_type == "select":
            page.locator(action["selector"]).select_option(action["value"])
        elif action_type == "check":
            page.locator(action["selector"]).check()
        elif action_type == "uncheck":
            page.locator(action["selector"]).uncheck()
        else:
            raise RuntimeError(f"지원하지 않는 녹화 동작입니다: {action_type}")

    @staticmethod
    def _replace(value: str, variables: dict[str, str]) -> str:
        result = value
        for key, replacement in variables.items():
            result = result.replace("{{" + key + "}}", replacement)
        if "{{" in result or "}}" in result:
            raise ValueError("녹화 재생에 필요한 값이 입력되지 않았습니다.")
        return result

    @staticmethod
    def _check_stop(stop_event: Event) -> None:
        if stop_event.is_set():
            raise RuntimeError("사용자가 재생을 중지했습니다.")

    @staticmethod
    def _launch(playwright: Playwright, options: dict) -> Browser:
        browser_type = getattr(playwright, options.get("browser", "chromium"))
        return browser_type.launch(
            headless=bool(options.get("headless", False)),
            slow_mo=int(options.get("slow_mo_ms", 0)),
        )
