"""업무 순서를 조합하는 애플리케이션 서비스."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from threading import Event
from typing import Callable

from automation.browser import BrowserSession
from automation.pages.login_page import LoginPage
from automation.pages.target_page import TargetPage


@dataclass(frozen=True)
class WorkflowInput:
    site_url: str
    username: str
    password: str
    work_date: str
    otp: str = ""


class AutomationWorkflow:
    def __init__(
        self,
        settings_path: Path,
        stop_event: Event,
        log: Callable[[str], None],
    ) -> None:
        self.settings_path = settings_path
        self.stop_event = stop_event
        self.log = log

    def run(self, workflow_input: WorkflowInput) -> None:
        settings = self._load_settings()
        self._validate_date(workflow_input.work_date)
        artifacts_dir = self.settings_path.parents[1] / "artifacts"
        timeout_ms = int(settings.get("timeouts", {}).get("element_ms", 10000))

        self.log("브라우저를 실행합니다.")
        session = BrowserSession(settings, artifacts_dir)
        try:
            with session.open() as page:
                page.set_default_timeout(timeout_ms)
                self.log(f"로그인 페이지로 이동합니다: {workflow_input.site_url}")
                page.goto(workflow_input.site_url, wait_until="domcontentloaded")

                self.log("로그인을 시도합니다.")
                LoginPage(
                    page, settings["selectors"]["login"], timeout_ms
                ).login(
                    workflow_input.username,
                    workflow_input.password,
                    workflow_input.otp,
                )
                self.log("로그인 완료.")

                self._check_stop()
                self.log("업무 등록을 수행합니다.")
                TargetPage(
                    page, settings["selectors"]["target"], timeout_ms
                ).execute(workflow_input.work_date, self.stop_event.is_set)
                self.log("업무 등록 완료.")
        except Exception:
            if session.last_failure_screenshot:
                self.log(f"실패 화면을 저장했습니다: {session.last_failure_screenshot}")
            raise

    def _load_settings(self) -> dict:
        try:
            with self.settings_path.open("r", encoding="utf-8") as file:
                settings = json.load(file)
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"설정 파일을 읽을 수 없습니다: {self.settings_path}") from exc

        if "selectors" not in settings:
            raise RuntimeError("설정 파일에 selectors 항목이 없습니다.")
        return settings

    def _check_stop(self) -> None:
        if self.stop_event.is_set():
            raise RuntimeError("사용자가 자동화를 중지했습니다.")

    @staticmethod
    def _validate_date(value: str) -> None:
        try:
            datetime.strptime(value, "%Y-%m-%d")
        except ValueError as exc:
            raise ValueError("업무 날짜는 YYYY-MM-DD 형식이어야 합니다.") from exc
